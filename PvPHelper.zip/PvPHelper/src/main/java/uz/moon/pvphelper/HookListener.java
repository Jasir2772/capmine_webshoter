package uz.moon.pvphelper;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** "hook" itemi: nishonlangan o'yinchini o'zingizga tortadi. Uzun kuldown (default 170 soniya). */
public class HookListener implements Listener {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public HookListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (!"hook".equals(type)) return;

        event.setUseItemInHand(Event.Result.DENY);

        Player player = event.getPlayer();
        FileConfiguration cfg = plugin.getConfig();
        String base = "items.hook.";

        long cdMs = (long) (cfg.getDouble(base + "cooldown", 170) * 1000);
        long left = cdMs - (System.currentTimeMillis() - cooldowns.getOrDefault(player.getUniqueId(), 0L));
        if (left > 0) {
            plugin.send(player, "hook-cooldown", "seconds", String.valueOf(left / 1000 + 1));
            return;
        }

        double range = cfg.getDouble(base + "range", 20);
        LivingEntity target = findTarget(player, range);
        if (target == null) {
            plugin.send(player, "hook-no-target");
            return;
        }

        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Nishonni o'ziga tortish
        double pullStrength = cfg.getDouble(base + "pull-strength", 1.6);
        Vector dir = player.getLocation().toVector().subtract(target.getLocation().toVector());
        if (dir.lengthSquared() > 0.01) {
            dir = dir.normalize().multiply(pullStrength);
            dir.setY(Math.max(dir.getY(), 0.35)); // yengil ko'tarilish, yerga yopishib qolmasligi uchun
            target.setVelocity(dir);
        }

        drawLine(player.getEyeLocation(), target.getLocation().add(0, 1, 0));
        playSound(player.getLocation(), base + "sounds.pull");
        if (target instanceof Player) {
            playSound(target.getLocation(), base + "sounds.pulled");
        }

        if (cfg.getBoolean(base + "consume", false)) {
            consume(item, player);
        }

        plugin.send(player, "hook-used",
                "player", target instanceof Player ? ((Player) target).getName() : target.getName());
        if (target instanceof Player) {
            plugin.send((Player) target, "hook-pulled", "player", player.getName());
        }
    }

    /** Ko'zdan qarab turgan chiziqqa eng yaqin jonli mavjudotni topadi. */
    private LivingEntity findTarget(Player player, double range) {
        RayTraceResult result = player.getWorld().rayTraceEntities(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range,
                0.4,
                e -> e instanceof LivingEntity && !e.equals(player));
        if (result == null || result.getHitEntity() == null) return null;
        return (LivingEntity) result.getHitEntity();
    }

    private void drawLine(Location from, Location to) {
        FileConfiguration cfg = plugin.getConfig();
        World w = from.getWorld();
        String particleName = cfg.getString("items.hook.particles.line", "CRIT_MAGIC");
        int count = cfg.getInt("items.hook.particles.line-count", 1);
        if (count <= 0) return;
        Particle particle;
        try {
            particle = Particle.valueOf(particleName.toUpperCase());
        } catch (IllegalArgumentException e) {
            particle = Particle.CRIT_MAGIC;
        }

        Vector path = to.toVector().subtract(from.toVector());
        double length = path.length();
        if (length < 0.001) return;
        Vector step = path.clone().normalize().multiply(0.4);

        for (double d = 0; d < length; d += 0.4) {
            Location point = from.clone().add(step.clone().multiply(d / 0.4));
            w.spawnParticle(particle, point, count, 0.05, 0.05, 0.05, 0.0);
        }
    }

    private void playSound(Location loc, String path) {
        FileConfiguration cfg = plugin.getConfig();
        String name = cfg.getString(path);
        if (name == null || name.isEmpty() || name.equalsIgnoreCase("NONE")) return;
        try {
            float volume = (float) cfg.getDouble("items.hook.sounds.volume", 1.0);
            float pitch = (float) cfg.getDouble("items.hook.sounds.pitch", 1.0);
            loc.getWorld().playSound(loc, Sound.valueOf(name.toUpperCase()), volume, pitch);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }
}
