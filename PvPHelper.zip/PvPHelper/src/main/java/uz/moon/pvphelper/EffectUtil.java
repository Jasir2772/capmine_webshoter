package uz.moon.pvphelper;

import org.bukkit.NamespacedKey;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;

public class EffectUtil {

    /**
     * "TUR:soniya:daraja" formatidagi qatorlarni effektlarga aylantiradi.
     * Daraja 0 = I daraja, 1 = II daraja va hokazo.
     * Masalan: "INCREASE_DAMAGE:15:1"
     */
    public static List<PotionEffect> parse(PvPHelperPlugin plugin, List<String> lines) {
        List<PotionEffect> result = new ArrayList<>();
        for (String line : lines) {
            if (line == null || line.trim().isEmpty()) continue;
            String[] p = line.trim().split(":");
            PotionEffectType type = findType(p[0].trim());
            if (type == null) {
                plugin.getLogger().warning("Noma'lum effekt: " + p[0]);
                continue;
            }
            try {
                int seconds = p.length > 1 ? Integer.parseInt(p[1].trim()) : 10;
                int amplifier = p.length > 2 ? Integer.parseInt(p[2].trim()) : 0;
                result.add(new PotionEffect(type, seconds * 20, amplifier));
            } catch (NumberFormatException e) {
                plugin.getLogger().warning("Effekt formati noto'g'ri: " + line);
            }
        }
        return result;
    }

    private static PotionEffectType findType(String name) {
        PotionEffectType type = PotionEffectType.getByKey(NamespacedKey.minecraft(name.toLowerCase()));
        if (type == null) type = PotionEffectType.getByName(name.toUpperCase());
        return type;
    }
}
