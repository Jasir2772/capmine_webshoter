package uz.moon.pvphelper;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** "frost" itemi: uloqtiriladigan qor parcha, tegsa dushmanni muzlatadi (Slowness). */
public class FrostListener implements Listener {

    private static final String META_KEY = "pvphelper_frost";

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public FrostListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (!"frost".equals(type)) return;

        event.setUseItemInHand(Event.Result.DENY);

        Player player = event.getPlayer();
        FileConfiguration cfg = plugin.getConfig();
        String base = "items.frost.";

        long cdMs = (long) (cfg.getDouble(base + "cooldown") * 1000);
        long left = cdMs - (System.currentTimeMillis() - cooldowns.getOrDefault(player.getUniqueId(), 0L));
        if (left > 0) {
            plugin.send(player, "frost-cooldown", "seconds", String.valueOf(left / 1000 + 1));
            return;
        }
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        Snowball ball = player.launchProjectile(Snowball.class);
        double speed = cfg.getDouble(base + "speed");
        ball.setVelocity(player.getEyeLocation().getDirection().multiply(speed));
        ball.setMetadata(META_KEY, new FixedMetadataValue(plugin, Boolean.TRUE));

        if (cfg.getBoolean(base + "consume")) {
            consume(item, player);
        }

        plugin.send(player, "frost-thrown");
    }

    @EventHandler
    public void onLaunch(ProjectileLaunchEvent event) {
        // Otilganda qanoat effekti (config'da yoqilsa)
        if (!(event.getEntity() instanceof Snowball) || !event.getEntity().hasMetadata(META_KEY)) return;
        FileConfiguration cfg = plugin.getConfig();
        String particle = cfg.getString("items.frost.particles.trail", "SNOWFLAKE");
        try {
            event.getEntity().getWorld().spawnParticle(
                    Particle.valueOf(particle.toUpperCase()), event.getEntity().getLocation(), 5, 0.1, 0.1, 0.1, 0.01);
        } catch (IllegalArgumentException ignored) {
        }
    }

    @EventHandler
    public void onHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Snowball) || !event.getEntity().hasMetadata(META_KEY)) return;

        FileConfiguration cfg = plugin.getConfig();
        String base = "items.frost.";
        Location hitLoc = event.getEntity().getLocation();

        // Portlash/urilish particle va ovoz
        try {
            String hitParticle = cfg.getString(base + "particles.hit", "SNOWFLAKE");
            int count = cfg.getInt(base + "particles.hit-count", 25);
            hitLoc.getWorld().spawnParticle(Particle.valueOf(hitParticle.toUpperCase()), hitLoc, count, 0.4, 0.4, 0.4, 0.1);
        } catch (IllegalArgumentException ignored) {
        }
        String soundName = cfg.getString(base + "sounds.hit", "BLOCK_GLASS_BREAK");
        if (soundName != null && !soundName.equalsIgnoreCase("NONE")) {
            try {
                float volume = (float) cfg.getDouble(base + "sounds.volume", 1.0);
                float pitch = (float) cfg.getDouble(base + "sounds.pitch", 1.2);
                hitLoc.getWorld().playSound(hitLoc, Sound.valueOf(soundName.toUpperCase()), volume, pitch);
            } catch (IllegalArgumentException ignored) {
            }
        }

        // Faqat jonli mavjudotga tegsa muzlatadi
        if (event.getHitEntity() instanceof LivingEntity) {
            LivingEntity target = (LivingEntity) event.getHitEntity();
            int seconds = cfg.getInt(base + "freeze-seconds", 7);
            int amplifier = cfg.getInt(base + "freeze-amplifier", 3);
            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, seconds * 20, amplifier));

            if (target instanceof Player) {
                plugin.send((Player) target, "frost-hit-you", "seconds", String.valueOf(seconds));
            }
            if (event.getEntity().getShooter() instanceof Player) {
                Player shooter = (Player) event.getEntity().getShooter();
                if (!shooter.equals(target)) {
                    plugin.send(shooter, "frost-hit-enemy",
                            "player", target instanceof Player ? ((Player) target).getName() : target.getName());
                }
            }
        }
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }
}
