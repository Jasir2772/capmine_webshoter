package uz.moon.pvphelper;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class ItemCommand implements CommandExecutor, TabCompleter {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;

    public ItemCommand(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String itemList = String.join(", ", ItemManager.IDS);

        // /pvpreload yoki /pvpitem reload
        boolean reload = command.getName().equalsIgnoreCase("pvpreload")
                || (args.length >= 1 && args[0].equalsIgnoreCase("reload"));
        if (reload) {
            if (!sender.hasPermission("pvphelper.reload")) {
                plugin.send(sender, "no-permission");
                return true;
            }
            plugin.reloadPlugin();
            plugin.send(sender, "reloaded");
            return true;
        }

        if (!(sender instanceof Player)) {
            plugin.send(sender, "only-player");
            return true;
        }
        Player player = (Player) sender;

        if (args.length < 1) {
            plugin.send(player, "usage", "items", itemList);
            return true;
        }

        ItemStack item = itemManager.createItem(args[0]);
        if (item == null) {
            plugin.send(player, "unknown-item", "items", itemList);
            return true;
        }

        player.getInventory().addItem(item);
        plugin.send(player, "item-received", "name", item.getItemMeta().getDisplayName());
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("pvpitem") && args.length == 1) {
            String prefix = args[0].toLowerCase();
            for (String id : ItemManager.IDS) {
                if (id.startsWith(prefix)) out.add(id);
            }
            if (sender.hasPermission("pvphelper.reload") && "reload".startsWith(prefix)) {
                out.add("reload");
            }
        }
        return out;
    }
}
