package uz.moon.pvphelper;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ItemCommand implements CommandExecutor {

    private final ItemManager itemManager;

    public ItemCommand(ItemManager itemManager) {
        this.itemManager = itemManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cBu buyruq faqat o'yinchi uchun!");
            return true;
        }
        Player player = (Player) sender;

        if (args.length < 1) {
            player.sendMessage("§eIshlatish: /pvpitem <bandage|rage|smoke|web>");
            return true;
        }

        ItemStack item = itemManager.getItemByName(args[0]);
        if (item == null) {
            player.sendMessage("§cBunday item topilmadi! Mavjud: bandage, rage, smoke, web");
            return true;
        }

        player.getInventory().addItem(item);
        player.sendMessage("§aItem olindingiz: " + item.getItemMeta().getDisplayName());
        return true;
    }
}
