package uz.moon.pvphelper;

import org.bukkit.plugin.java.JavaPlugin;

public class PvPHelperPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // config.yml ni yaratadi (bir marta)
        saveDefaultConfig();

        ItemManager itemManager = new ItemManager(this);
        this.getCommand("pvpitem").setExecutor(new ItemCommand(itemManager));
        getServer().getPluginManager().registerEvents(new ItemListener(this, itemManager), this);
        getServer().getPluginManager().registerEvents(new WebShooterListener(this, itemManager), this);
        getLogger().info("PvPHelper yoqildi!");
    }

    @Override
    public void onDisable() {
        getLogger().info("PvPHelper o'chirildi!");
    }
}
