package uz.moon.pvphelper;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PvPHelperPlugin extends JavaPlugin {

    private ItemManager itemManager;

    @Override
    public void onEnable() {
        // config.yml ni yaratadi (bir marta)
        saveDefaultConfig();

        itemManager = new ItemManager(this);

        ItemCommand command = new ItemCommand(this, itemManager);
        getCommand("pvpitem").setExecutor(command);
        getCommand("pvpitem").setTabCompleter(command);
        getCommand("pvpreload").setExecutor(command);

        getServer().getPluginManager().registerEvents(new ItemListener(this, itemManager), this);
        getServer().getPluginManager().registerEvents(new WebShooterListener(this, itemManager), this);
        getServer().getPluginManager().registerEvents(new FrostListener(this, itemManager), this);
        getServer().getPluginManager().registerEvents(new HookListener(this, itemManager), this);
        getLogger().info("PvPHelper yoqildi!");
    }

    @Override
    public void onDisable() {
        getLogger().info("PvPHelper o'chirildi!");
    }

    /** config.yml ni diskdan qayta o'qiydi. */
    public void reloadPlugin() {
        reloadConfig();
    }

    private static final Pattern GRADIENT = Pattern.compile(
            "<gradient:#([0-9a-fA-F]{6}):#([0-9a-fA-F]{6})(?::([a-zA-Z]*))?>(.*?)</gradient>");
    private static final Pattern HEX = Pattern.compile("&#([0-9a-fA-F]{6})");

    /**
     * Rang formatlari:
     *  &c, &l ...                       — oddiy Minecraft ranglari
     *  &#FF8800                         — HEX rang
     *  <gradient:#FF0000:#0000FF>Matn</gradient>       — gradient (rangdan rangga)
     *  <gradient:#FF0000:#0000FF:lo>Matn</gradient>    — gradient + qalin (l), qiya (o) ...
     */
    public String color(String text) {
        if (text == null) return "";

        Matcher g = GRADIENT.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (g.find()) {
            String styles = g.group(3) == null ? "" : g.group(3);
            String colored = gradient(g.group(4), g.group(1), g.group(2), styles);
            g.appendReplacement(sb, Matcher.quoteReplacement(colored));
        }
        g.appendTail(sb);
        text = sb.toString();

        Matcher h = HEX.matcher(text);
        sb = new StringBuffer();
        while (h.find()) {
            h.appendReplacement(sb, Matcher.quoteReplacement(hexToLegacy(h.group(1))));
        }
        h.appendTail(sb);
        text = sb.toString();

        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private String hexToLegacy(String hex) {
        StringBuilder out = new StringBuilder("\u00a7x");
        for (char c : hex.toCharArray()) {
            out.append('\u00a7').append(c);
        }
        return out.toString();
    }

    private String gradient(String text, String fromHex, String toHex, String styles) {
        int r1 = Integer.parseInt(fromHex.substring(0, 2), 16);
        int g1 = Integer.parseInt(fromHex.substring(2, 4), 16);
        int b1 = Integer.parseInt(fromHex.substring(4, 6), 16);
        int r2 = Integer.parseInt(toHex.substring(0, 2), 16);
        int g2 = Integer.parseInt(toHex.substring(2, 4), 16);
        int b2 = Integer.parseInt(toHex.substring(4, 6), 16);

        StringBuilder styleCodes = new StringBuilder();
        for (char c : styles.toLowerCase().toCharArray()) {
            styleCodes.append('\u00a7').append(c);
        }

        int n = text.length();
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < n; i++) {
            double t = n == 1 ? 0 : (double) i / (n - 1);
            int r = (int) Math.round(r1 + (r2 - r1) * t);
            int gr = (int) Math.round(g1 + (g2 - g1) * t);
            int b = (int) Math.round(b1 + (b2 - b1) * t);
            out.append(hexToLegacy(String.format("%02x%02x%02x", r, gr, b)));
            out.append(styleCodes);
            out.append(text.charAt(i));
        }
        return out.toString();
    }

    /** messages.<key> ni oladi, {kalit} o'rinlarini almashtiradi. */
    public String msg(String key, String... replacements) {
        String text = getConfig().getString("messages." + key);
        if (text == null) return "";
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        return color(text);
    }

    /** Xabarni yuboradi (config'da bo'sh qoldirilsa, yubormaydi). */
    public void send(CommandSender to, String key, String... replacements) {
        String text = msg(key, replacements);
        if (!text.isEmpty()) to.sendMessage(text);
    }
}
