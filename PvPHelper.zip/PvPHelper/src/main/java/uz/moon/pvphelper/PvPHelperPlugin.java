package uz.moon.pvphelper;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class PvPHelperPlugin extends JavaPlugin {

    private ItemManager itemManager;

    @Override
    public void onEnable() {
        // config.yml ni yaratadi (bir marta)
        saveDefaultConfig();

        itemManager = new ItemManager(this);

        ItemCommand command = new ItemCommand(this, itemManager);
        getCommand("pvpitem").setExecutor(command);
        getCommand("pvpitem").setTabCompleter(command);
        getCommand("pvpreload").setExecutor(command);

        getServer().getPluginManager().registerEvents(new ItemListener(this, itemManager), this);
        getServer().getPluginManager().registerEvents(new WebShooterListener(this, itemManager), this);
        getLogger().info("PvPHelper yoqildi!");
    }

    @Override
    public void onDisable() {
        getLogger().info("PvPHelper o'chirildi!");
    }

    /** config.yml ni diskdan qayta o'qiydi. */
    public void reloadPlugin() {
        reloadConfig();
    }

    /** & rang kodlarini § ga aylantiradi. */
    public String color(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    /** messages.<key> ni oladi, {kalit} o'rinlarini almashtiradi. */
    public String msg(String key, String... replacements) {
        String text = getConfig().getString("messages." + key);
        if (text == null) return "";
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace("{" + replacements[i] + "}", replacements[i + 1]);
        }
        return color(text);
    }

    /** Xabarni yuboradi (config'da bo'sh qoldirilsa, yubormaydi). */
    public void send(CommandSender to, String key, String... replacements) {
        String text = msg(key, replacements);
        if (!text.isEmpty()) to.sendMessage(text);
    }
}
