package uz.moon.pvphelper;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ItemManager {

    public static final List<String> IDS = Arrays.asList("bandage", "rage", "smoke", "web");

    private final PvPHelperPlugin plugin;
    private final NamespacedKey key;

    public ItemManager(PvPHelperPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "pvpitem");
    }

    public NamespacedKey getKey() {
        return key;
    }

    /** Itemni config.yml dagi items.<id> bo'limidan yasaydi. */
    public ItemStack createItem(String id) {
        id = id.toLowerCase();
        if (!IDS.contains(id)) return null;

        FileConfiguration cfg = plugin.getConfig();
        String base = "items." + id + ".";

        String matName = cfg.getString(base + "material");
        Material mat = matName == null ? null : Material.matchMaterial(matName);
        if (mat == null || !mat.isItem() || mat.isAir()) {
            plugin.getLogger().warning("items." + id + ".material noto'g'ri: " + matName + " (PAPER ishlatildi)");
            mat = Material.PAPER;
        }

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(plugin.color(cfg.getString(base + "name")));

        List<String> lore = new ArrayList<>();
        for (String line : cfg.getStringList(base + "lore")) {
            lore.add(plugin.color(line));
        }
        meta.setLore(lore);

        int model = cfg.getInt(base + "custom-model-data");
        if (model > 0) {
            meta.setCustomModelData(model);
        }

        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);

        if (cfg.getBoolean(base + "glow")) {
            meta.addEnchant(Enchantment.DURABILITY, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        item.setItemMeta(meta);
        return item;
    }
}
