package uz.moon.pvphelper;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.Arrays;

public class ItemManager {

    private final Plugin plugin;
    private final NamespacedKey key;

    public ItemManager(Plugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "pvpitem");
    }

    public NamespacedKey getKey() {
        return key;
    }

    public ItemStack getBandage() {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§c§lTaktik Bint");
        meta.setLore(Arrays.asList(
                "§7O'ng tugma: 4 talik yurak davolaydi",
                "§8Kuldown: 10 soniya"
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "bandage");
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack getRageOrb() {
        ItemStack item = new ItemStack(Material.BLAZE_POWDER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6§lG'azab Orbi");
        meta.setLore(Arrays.asList(
                "§7O'ng tugma: Kuch II + Tezlik I (15 soniya)",
                "§8Kuldown: 30 soniya"
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "rage");
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack getSmokeBomb() {
        ItemStack item = new ItemStack(Material.COAL);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§8§lTutun Bombasi");
        meta.setLore(Arrays.asList(
                "§7O'ng tugma: 5 blok radiusdagi",
                "§7dushmanlarga ko'rinish 0 (8 soniya)",
                "§8Kuldown: 20 soniya"
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "smoke");
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack getWebShooter() {
        ItemStack item = new ItemStack(Material.FISHING_ROD);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§f§lTo'r Otuvchi");
        meta.setLore(Arrays.asList(
                "§7O'ng tugma: binoga to'r otib",
                "§7unga uchib boring!",
                "§7Shift bosib to'xtating",
                "§8Sozlamalar: config.yml"
        ));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, "web");
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack getItemByName(String name) {
        switch (name.toLowerCase()) {
            case "bandage": return getBandage();
            case "rage": return getRageOrb();
            case "smoke": return getSmokeBomb();
            case "web": return getWebShooter();
            default: return null;
        }
    }
}
