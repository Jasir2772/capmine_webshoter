package uz.moon.pvphelper;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ItemListener implements Listener {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public ItemListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (type == null) return;

        // "web", "frost" va "hook" alohida listenerlarda ishlaydi
        if (type.equals("web") || type.equals("frost") || type.equals("hook")
                || !ItemManager.IDS.contains(type)) return;

        // Item blok bo'lib joylashib ketmasligi uchun
        event.setUseItemInHand(Event.Result.DENY);

        Player player = event.getPlayer();
        FileConfiguration cfg = plugin.getConfig();
        String base = "items." + type + ".";

        long cooldownMs = (long) (cfg.getDouble(base + "cooldown") * 1000);
        long left = cooldownMs - (System.currentTimeMillis() - getLastUse(player, type));
        if (left > 0) {
            plugin.send(player, "cooldown", "seconds", String.valueOf(left / 1000 + 1));
            return;
        }

        switch (type) {
            case "bandage": {
                double heal = cfg.getDouble(base + "heal");
                double newHealth = Math.min(player.getHealth() + heal, player.getMaxHealth());
                player.setHealth(newHealth);
                plugin.send(player, "bandage-used");
                break;
            }

            case "rage": {
                for (PotionEffect effect : EffectUtil.parse(plugin, cfg.getStringList(base + "effects"))) {
                    player.addPotionEffect(effect);
                }
                plugin.send(player, "rage-used");
                break;
            }

            case "smoke": {
                double radius = cfg.getDouble(base + "radius");
                java.util.List<PotionEffect> effects = EffectUtil.parse(plugin, cfg.getStringList(base + "effects"));
                int affected = 0;
                for (Player other : player.getWorld().getPlayers()) {
                    if (other.equals(player)) continue;
                    if (other.getLocation().distance(player.getLocation()) <= radius) {
                        for (PotionEffect effect : effects) {
                            other.addPotionEffect(effect);
                        }
                        plugin.send(other, "smoke-hit", "player", player.getName());
                        affected++;
                    }
                }
                plugin.send(player, "smoke-used", "count", String.valueOf(affected));
                break;
            }
        }

        if (cfg.getBoolean(base + "consume")) {
            consume(item, player);
        }

        setLastUse(player, type);
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }

    private long getLastUse(Player player, String type) {
        Map<String, Long> map = cooldowns.get(player.getUniqueId());
        if (map == null) return 0L;
        return map.getOrDefault(type, 0L);
    }

    private void setLastUse(Player player, String type) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                 .put(type, System.currentTimeMillis());
    }
}
