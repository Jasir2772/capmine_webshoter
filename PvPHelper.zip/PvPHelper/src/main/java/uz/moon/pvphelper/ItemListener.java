package uz.moon.pvphelper;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ItemListener implements Listener {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();

    public ItemListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (type == null) return;

        // "web" WebShooterListener da alohida ishlaydi
        if (type.equals("web")) return;

        Player player = event.getPlayer();

        long cooldownMs = getCooldownMs(type);
        if (!checkCooldown(player, type, cooldownMs)) {
            long left = (cooldownMs - (System.currentTimeMillis() - getLastUse(player, type))) / 1000;
            player.sendMessage("§eKutishingiz kerak: " + (left + 1) + " soniya");
            return;
        }

        switch (type) {
            case "bandage":
                double newHealth = Math.min(player.getHealth() + 8.0, player.getMaxHealth());
                player.setHealth(newHealth);
                player.sendMessage("§aSiz davolandiz!");
                consume(item, player);
                break;

            case "rage":
                player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 15 * 20, 1));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 15 * 20, 0));
                player.sendMessage("§6G'azab ko'tarildi!");
                consume(item, player);
                break;

            case "smoke":
                int affected = 0;
                for (Player other : player.getWorld().getPlayers()) {
                    if (other.equals(player)) continue;
                    if (other.getLocation().distance(player.getLocation()) <= 5) {
                        other.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 8 * 20, 0));
                        other.sendMessage("§8Tutun ichidasiz! " + player.getName() + " bombasidan");
                        affected++;
                    }
                }
                player.sendMessage("§7" + affected + " ta dushman ta'sirlandi!");
                consume(item, player);
                break;
        }

        setLastUse(player, type);
    }

    private long getCooldownMs(String type) {
        switch (type) {
            case "bandage": return 10_000;
            case "rage": return 30_000;
            case "smoke": return 20_000;
            default: return 0;
        }
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().remove(item);
        }
    }

    private boolean checkCooldown(Player player, String type, long ms) {
        long last = getLastUse(player, type);
        return System.currentTimeMillis() - last >= ms;
    }

    private long getLastUse(Player player, String type) {
        return cooldowns.getOrDefault(player.getUniqueId(), new HashMap<>()).getOrDefault(type, 0L);
    }

    private void setLastUse(Player player, String type) {
        cooldowns.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>())
                 .put(type, System.currentTimeMillis());
    }
}
