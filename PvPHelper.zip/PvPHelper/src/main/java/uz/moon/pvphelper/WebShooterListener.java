package uz.moon.pvphelper;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class WebShooterListener implements Listener {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> swinging = new HashSet<>();

    public WebShooterListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (!"web".equals(type)) return;

        Player player = event.getPlayer();
        FileConfiguration cfg = plugin.getConfig();

        // Kuldown
        long cdSec = cfg.getLong("webshooter.cooldown", 6);
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        long leftMs = cdSec * 1000 - (System.currentTimeMillis() - last);
        if (leftMs > 0) {
            player.sendMessage("§eKuldown: " + ((leftMs / 1000) + 1) + " soniya");
            return;
        }

        // Nishonni topish (blokni nishonga olamiz)
        double range = cfg.getDouble("webshooter.range", 35);
        RayTraceResult result = player.getWorld().rayTraceBlocks(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range);

        if (result == null || result.getHitBlock() == null) {
            player.sendMessage("§cHech narsa topilmadi — yaqinroq nishonlang!");
            return;
        }

        Location target = result.getHitPosition().toLocation(player.getWorld());
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Effektlar
        playSound(player, cfg.getString("webshooter.sounds.shoot", "ENTITY_ARROW_SHOOT"), cfg);
        drawWebLine(player.getEyeLocation(), target, cfg);
        spawnBurst(target, cfg);
        playSoundAt(target, cfg.getString("webshooter.sounds.hit", "BLOCK_SLIME_BLOCK_HIT"), cfg);

        if (cfg.getBoolean("webshooter.consume-item", false)) {
            consume(item, player);
        }

        startSwing(player, target, cfg);
    }

    // O'yinchini nishonga tortib borish
    private void startSwing(Player player, Location target, FileConfiguration cfg) {
        double speed = cfg.getDouble("webshooter.speed", 1.8);
        double stopDist = cfg.getDouble("webshooter.stop-distance", 2.5);

        swinging.add(player.getUniqueId());

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                ticks++;

                boolean arrived = player.getLocation().distance(target) <= stopDist;
                if (!player.isOnline() || player.isSneaking() || arrived || ticks > 300) {
                    swinging.remove(player.getUniqueId());
                    if (player.isOnline() && cfg.getBoolean("webshooter.safe-landing", true)) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 60, 0));
                    }
                    cancel();
                    return;
                }

                Vector dir = target.toVector().subtract(player.getLocation().toVector());
                if (dir.lengthSquared() < 0.001) {
                    cancel();
                    return;
                }
                player.setVelocity(dir.normalize().multiply(speed));

                // Uchish izi (trail) — har 2 tikda
                if (ticks % 2 == 0) {
                    spawnTrail(player.getLocation(), cfg);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // Ko'tarilganda qulash zararini bekor qilish
    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && swinging.contains(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    // ========== Yordamchi metodlar ==========

    // Ko'zdan nishonga qadar to'r chizig'i chizish
    private void drawWebLine(Location from, Location to, FileConfiguration cfg) {
        World w = from.getWorld();
        Particle particle = getParticle(cfg.getString("webshooter.particles.line-particle", "ITEM_CRACK"));
        Material itemMaterial = Material.matchMaterial(cfg.getString("webshooter.particles.line-item", "COBWEB"));
        int count = cfg.getInt("webshooter.particles.line-count", 2);

        Vector path = to.toVector().subtract(from.toVector());
        double length = path.length();
        Vector step = path.clone().normalize().multiply(0.4);

        for (double d = 0; d < length; d += 0.4) {
            Location point = from.clone().add(step.clone().multiply(d / 0.4));
            spawnParticle(w, particle, point, count, itemMaterial);
        }
    }

    // Nishonda portlash effekti
    private void spawnBurst(Location loc, FileConfiguration cfg) {
        Particle particle = getParticle(cfg.getString("webshooter.particles.hit-particle", "CRIT_MAGIC"));
        int count = cfg.getInt("webshooter.particles.hit-count", 30);
        loc.getWorld().spawnParticle(particle, loc, count, 0.4, 0.4, 0.4, 0.15);
    }

    // Uchish izi
    private void spawnTrail(Location loc, FileConfiguration cfg) {
        World w = loc.getWorld();
        Particle particle = getParticle(cfg.getString("webshooter.particles.trail-particle", "ITEM_CRACK"));
        Material itemMaterial = Material.matchMaterial(cfg.getString("webshooter.particles.trail-item", "COBWEB"));
        int count = cfg.getInt("webshooter.particles.trail-count", 3);
        spawnParticle(w, particle, loc, count, itemMaterial);
    }

    private void spawnParticle(World w, Particle particle, Location loc, int count, Material itemMaterial) {
        if (particle == Particle.ITEM_CRACK && itemMaterial != null) {
            w.spawnParticle(particle, loc, count, 0.08, 0.08, 0.08, 0.01, new ItemStack(itemMaterial));
        } else {
            w.spawnParticle(particle, loc, count, 0.08, 0.08, 0.08, 0.01);
        }
    }

    private Particle getParticle(String name) {
        try {
            return Particle.valueOf(name);
        } catch (Exception e) {
            return Particle.CRIT_MAGIC;
        }
    }

    private void playSound(Player player, String name, FileConfiguration cfg) {
        try {
            Sound sound = Sound.valueOf(name);
            float volume = (float) cfg.getDouble("webshooter.sounds.volume", 1.0);
            float pitch = (float) cfg.getDouble("webshooter.sounds.pitch", 1.0);
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (Exception ignored) {}
    }

    private void playSoundAt(Location loc, String name, FileConfiguration cfg) {
        try {
            Sound sound = Sound.valueOf(name);
            float volume = (float) cfg.getDouble("webshooter.sounds.volume", 1.0);
            float pitch = (float) cfg.getDouble("webshooter.sounds.pitch", 1.0);
            loc.getWorld().playSound(loc, sound, volume, pitch);
        } catch (Exception ignored) {}
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().remove(item);
        }
    }
}
