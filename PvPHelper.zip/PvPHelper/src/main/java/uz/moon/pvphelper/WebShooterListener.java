package uz.moon.pvphelper;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class WebShooterListener implements Listener {

    private final PvPHelperPlugin plugin;
    private final ItemManager itemManager;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> swinging = new HashSet<>();

    public WebShooterListener(PvPHelperPlugin plugin, ItemManager itemManager) {
        this.plugin = plugin;
        this.itemManager = itemManager;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        ItemMeta meta = item.getItemMeta();
        String type = meta.getPersistentDataContainer()
                .get(itemManager.getKey(), PersistentDataType.STRING);
        if (!"web".equals(type)) return;

        // Item blok bo'lib joylashib ketmasligi (yoki qarmoq otilmasligi) uchun
        event.setUseItemInHand(Event.Result.DENY);

        Player player = event.getPlayer();
        FileConfiguration cfg = plugin.getConfig();

        // Kuldown
        double cdSec = cfg.getDouble("webshooter.cooldown");
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        long leftMs = (long) (cdSec * 1000) - (System.currentTimeMillis() - last);
        if (leftMs > 0) {
            plugin.send(player, "web-cooldown", "seconds", String.valueOf(leftMs / 1000 + 1));
            return;
        }

        // Nishonni topish (blokni nishonga olamiz)
        double range = cfg.getDouble("webshooter.range");
        RayTraceResult result = player.getWorld().rayTraceBlocks(
                player.getEyeLocation(),
                player.getEyeLocation().getDirection(),
                range);

        if (result == null || result.getHitBlock() == null) {
            plugin.send(player, "web-no-target");
            return;
        }

        Location target = result.getHitPosition().toLocation(player.getWorld());
        cooldowns.put(player.getUniqueId(), System.currentTimeMillis());

        // Effektlar
        playSound(player.getLocation(), "shoot", player);
        drawWebLine(player.getEyeLocation(), target);
        spawnBurst(target);
        playSound(target, "hit", null);

        if (cfg.getBoolean("webshooter.consume-item")) {
            consume(item, player);
        }

        startSwing(player, target);
    }

    // O'yinchini nishonga tortib borish
    private void startSwing(Player player, Location target) {
        swinging.add(player.getUniqueId());

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                // Sozlamalar har tikda qayta o'qiladi (reload darrov ta'sir qiladi)
                FileConfiguration cfg = plugin.getConfig();
                double speed = cfg.getDouble("webshooter.speed");
                double stopDist = cfg.getDouble("webshooter.stop-distance");
                int maxTicks = (int) (cfg.getDouble("webshooter.max-duration") * 20);
                boolean stopOnSneak = cfg.getBoolean("webshooter.stop-on-sneak");

                ticks++;

                boolean arrived = player.getLocation().distance(target) <= stopDist;
                boolean sneakStop = stopOnSneak && player.isSneaking();
                if (!player.isOnline() || sneakStop || arrived || ticks > maxTicks) {
                    swinging.remove(player.getUniqueId());
                    if (player.isOnline() && cfg.getBoolean("webshooter.safe-landing")) {
                        int landTicks = (int) (cfg.getDouble("webshooter.safe-landing-seconds") * 20);
                        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, landTicks, 0));
                    }
                    cancel();
                    return;
                }

                Vector dir = target.toVector().subtract(player.getLocation().toVector());
                if (dir.lengthSquared() < 0.001) {
                    swinging.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                player.setVelocity(dir.normalize().multiply(speed));

                // Uchish izi (trail)
                int interval = Math.max(1, cfg.getInt("webshooter.particles.trail-interval"));
                if (ticks % interval == 0) {
                    spawnTrail(player.getLocation());
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // Ko'tarilganda qulash zararini bekor qilish
    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL
                && swinging.contains(event.getEntity().getUniqueId())) {
            event.setCancelled(true);
        }
    }

    // ========== Yordamchi metodlar ==========

    // Ko'zdan nishonga qadar to'r chizig'i chizish
    private void drawWebLine(Location from, Location to) {
        FileConfiguration cfg = plugin.getConfig();
        World w = from.getWorld();
        Particle particle = getParticle(cfg.getString("webshooter.particles.line-particle"));
        Material itemMaterial = getMaterial(cfg.getString("webshooter.particles.line-item"));
        int count = cfg.getInt("webshooter.particles.line-count");
        if (count <= 0) return;

        Vector path = to.toVector().subtract(from.toVector());
        double length = path.length();
        if (length < 0.001) return;
        Vector step = path.clone().normalize().multiply(0.4);

        for (double d = 0; d < length; d += 0.4) {
            Location point = from.clone().add(step.clone().multiply(d / 0.4));
            spawnParticle(w, particle, point, count, itemMaterial);
        }
    }

    // Nishonda portlash effekti
    private void spawnBurst(Location loc) {
        FileConfiguration cfg = plugin.getConfig();
        Particle particle = getParticle(cfg.getString("webshooter.particles.hit-particle"));
        int count = cfg.getInt("webshooter.particles.hit-count");
        if (count <= 0) return;
        loc.getWorld().spawnParticle(particle, loc, count, 0.4, 0.4, 0.4, 0.15);
    }

    // Uchish izi
    private void spawnTrail(Location loc) {
        FileConfiguration cfg = plugin.getConfig();
        Particle particle = getParticle(cfg.getString("webshooter.particles.trail-particle"));
        Material itemMaterial = getMaterial(cfg.getString("webshooter.particles.trail-item"));
        int count = cfg.getInt("webshooter.particles.trail-count");
        if (count <= 0) return;
        spawnParticle(loc.getWorld(), particle, loc, count, itemMaterial);
    }

    private void spawnParticle(World w, Particle particle, Location loc, int count, Material itemMaterial) {
        if (particle == Particle.ITEM_CRACK && itemMaterial != null) {
            w.spawnParticle(particle, loc, count, 0.08, 0.08, 0.08, 0.01, new ItemStack(itemMaterial));
        } else {
            w.spawnParticle(particle, loc, count, 0.08, 0.08, 0.08, 0.01);
        }
    }

    private Particle getParticle(String name) {
        try {
            return Particle.valueOf(name.toUpperCase());
        } catch (Exception e) {
            return Particle.CRIT_MAGIC;
        }
    }

    private Material getMaterial(String name) {
        if (name == null) return Material.COBWEB;
        Material m = Material.matchMaterial(name);
        return m == null ? Material.COBWEB : m;
    }

    /** Ovoz chalish. onlyFor berilsa faqat shu o'yinchi eshitadi, aks holda hamma. */
    private void playSound(Location loc, String which, Player onlyFor) {
        FileConfiguration cfg = plugin.getConfig();
        String name = cfg.getString("webshooter.sounds." + which);
        if (name == null || name.isEmpty() || name.equalsIgnoreCase("NONE")) return;
        try {
            Sound sound = Sound.valueOf(name.toUpperCase());
            float volume = (float) cfg.getDouble("webshooter.sounds.volume");
            float pitch = (float) cfg.getDouble("webshooter.sounds.pitch");
            if (onlyFor != null) {
                onlyFor.playSound(loc, sound, volume, pitch);
            } else {
                loc.getWorld().playSound(loc, sound, volume, pitch);
            }
        } catch (IllegalArgumentException ignored) {
            // Noto'g'ri ovoz nomi — o'tkazib yuboriladi
        }
    }

    private void consume(ItemStack item, Player player) {
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
    }
}
